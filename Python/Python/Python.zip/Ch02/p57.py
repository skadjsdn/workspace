"""
f = int(input('지방의 그램을 입력하세요 : '))
c = int(input('탄수화물의 그램을 입력하세요 :'))
p = int(input('단백질의 그램을 입력하세요 :'))
result = f*9+c*4+p*4
print('총 칼로리 :', result)
"""
word1 = input('첫번째 단어 :')
word2 = input('두번째 단어 :')
word3 = input('세번째 단어 :')

word4 = word1[0]+word2[0]+word3[0]
print('약자 :', word4)

