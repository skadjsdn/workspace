"""
날짜 : 2021/08/09
이름 : 남언우
내용 : 파이썬 변수 실습하기 교재 p34
"""
var1 = 1
var2 = 2
var3 = var1+var2
print('var3:',var3)
