"""
날짜 : 2021/08/09
이름 : 남언우
내용 : 파이썬 자료형 실습하기 교재 p37
"""
# 숫자형(int)
var1 = 1
var2 = 2
var3 = -3
print('var1:',var1)
print('var2:',var2)
print('var3:',var3)
print('var1 type:',type(var1))
print('var2 type:',type(var2))
print('var3 type:',type(var3))

# 실수형(float)
var4= 0.4
var5 = -1.2354
print('var4:',var4)
print('var5:',var5)
print('var4 tpye', type(var4))
print('var5 tpye', type(var5))

# 논리형(bool)
var6 = True
var7 = False
print('var6:',var6)
print('var7:',var7)
print('var6 type', type(var6))
print('var7 type', type(var7))












