su = 5
dan = 800
result = su * dan

print('su의 주소 :',id(su))
print('dan 주소 :',id(dan))
print('금액 : ', result)


x = int(input("숫자입력"))
y = 2.5*x*x+3.3*x+6
print('2차 방정식 결과 : ', y)
