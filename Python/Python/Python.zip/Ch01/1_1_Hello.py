"""
날짜 : 2021/08/09
이름 : 남언우
내용 : 파이썬 개발환경 설정 교재 p15
"""

print('Hello World')
print('Hello Python!')
print('hello', end='!!!!!')
print('dddd')

