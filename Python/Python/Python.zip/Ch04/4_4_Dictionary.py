
dic1 = {
    'A' : 'apple',
    'B' : 'Banana',
    'C' : 'Cherry'
}
print('dic1 type :', type(dic1))
print('dic:', dic1)
print("dic1['A'] :", dic1['A'])
print("dic1['B'] :", dic1['B'])
print("dic1['C'] :", dic1['C'])

dic3 = {
    101:[1, 2, 3, 4, 5],
    102:[6, 7, 8, 9, 10],
    103 : {'한국', '미국', '일본'},
    104 : { 'p1' : '김유신', 'p2' : '김춘추'}
}
print('dic3', dic3[101])
print('dic3', dic3[102])
print('dic3', dic3[103])
print('dic3', dic3[104]['p1'])



