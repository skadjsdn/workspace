def plus(x, y):
    return x+y
def minus(x, y):
    return x-y
def multi(x, y):
    return x*y
def div(x, y):
    return x/y
